using UnityEngine;

public class PlayerController: MonoBehaviour
{
    private Vector3 _input;

    [SerializeField] private Rigidbody _rb;
    [SerializeField] private float _spd = 5;
    [SerializeField] private float _turnspd = 360;
    [SerializeField] private bool _squatPopped;


    [SerializeField] private float groundCheckDistance = 1.1f;
    [SerializeField] private LayerMask groundLayer;

    [SerializeField] private CapsuleCollider _cap;
    [SerializeField] private float groundExtra = 0.1f;

    [SerializeField] private float rainTimer;
    [SerializeField] private GameObject interactUI;

    private bool isGrounded;

    public bool canMove;

    public bool squatPopped => _squatPopped;


    private void Start()
    {
        canMove = true;
    }

    private void Update()
    {
        //Debug.Log(rainTimer);
        rainTimer -= Time.deltaTime;
        if (rainTimer < 0f)
        {
            interactUI.SetActive(true);
            return;
        }

        if (!canMove)
        {
            _input = Vector3.zero;
            _rb.linearVelocity = Vector3.zero; // optional, helps if you ever use rb velocity elsewhere
            _rb.angularVelocity = Vector3.zero;
        }
        GatherInput();
        Look();
    }

    private void FixedUpdate()
    {
        
        if (!canMove)
        {
            _input = Vector3.zero;
            _rb.linearVelocity = Vector3.zero; // optional, helps if you ever use rb velocity elsewhere
            _rb.angularVelocity = Vector3.zero;
            return;
        }


        isGrounded = CheckGrounded();


        if (isGrounded && _rb.linearVelocity.y < 0f)
        {
            var v = _rb.linearVelocity;
            v.y = -2f; // keeps contact stable on slopes
            _rb.linearVelocity = v;
        }
        Move();
    }

    void GatherInput() {

        _input = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical"));

        // For poppin a squat
        _squatPopped = Input.GetKey(KeyCode.LeftControl);
    
    }

    void Look() {

        if (_squatPopped) { 
        
            float turnAmount = _input.x * _turnspd * Time.deltaTime;
            transform.Rotate(Vector3.up, turnAmount);
            return;
        }

        if(_input != Vector3.zero) {

            var matrix = Matrix4x4.Rotate(Quaternion.Euler(0,45,0));
            var skewedInput = matrix.MultiplyPoint3x4(_input);

            var relative = (transform.position + skewedInput) - transform.position;
            var rot = Quaternion.LookRotation(relative, Vector3.up);

            transform.rotation = Quaternion.RotateTowards(transform.rotation,rot,_turnspd * Time.deltaTime);
        }


    
    }

    void Move() {

        // Dont move while squatting
        if (_squatPopped) return;

        _rb.MovePosition(transform.position + (transform.forward * _input.magnitude) * _spd * Time.deltaTime);
    }

    bool CheckGrounded()
    {
        if (_cap == null) return false;

        // Use the capsule bounds so it works even if pivot is at center
        Vector3 origin = _cap.bounds.center;

        // Slightly smaller than the collider radius so it doesn't hit walls
        float radius = _cap.radius * 0.95f;

        // Distance from center to bottom of capsule, plus a small buffer
        float castDist = (_cap.bounds.extents.y - radius) + groundExtra;

        return Physics.SphereCast(origin, radius, Vector3.down, out _, castDist, groundLayer, QueryTriggerInteraction.Ignore);
    }

}
