using System.Runtime.InteropServices;
using UnityEngine;

public class CollectibleScript : MonoBehaviour
{
    public GameObject bottleCorona;
    public bool canGrabCorona = false;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (canGrabCorona && Input.GetKeyDown(KeyCode.E))
        {
            
            bottleCorona.SetActive(false);

            
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("RainWizard"))
        {
            canGrabCorona = true;
            Debug.Log("can grab corona");
        }


    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("RainWizard"))
        {
            canGrabCorona = false;
        }


    }
}
