using UnityEngine;




public class RadioTowerScript : MonoBehaviour
{
    public PoleScript pole1;
    public PoleScript pole2;
    public PoleScript pole3;
    public bool topOfTower = false;
    public int megaCharge;

    [SerializeField] private GameObject interactUI;

    public Transform rainW;
    private bool canClimb = false;

    public GameObject topPole;

    public Transform topofPole;



    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        

    }

    // Update is called once per frame
    void Update()
    {
        if (topOfTower)
        {
            if(pole1.charged && pole2.charged && pole3.charged)

                if (canClimb && Input.GetKeyDown(KeyCode.E))
                {
                    var cc = rainW.GetComponent<CharacterController>();
                    if (cc != null) cc.enabled = false;

                    rainW.position = topofPole.position;
                    Physics.SyncTransforms(); // helps triggers update after teleport

                    if (cc != null) cc.enabled = true;

                    var mover = rainW.GetComponent<RainWizzardScript>();
                    if (mover != null) mover.ResetVerticalVelocity();

                    var rb = rainW.GetComponent<Rigidbody>();
                    if (rb != null)
                    {
                        rb.freezeRotation = true;
                    }

                    rainW.rotation = Quaternion.identity;



                    Debug.Log("Rain Wizard is on the pole");




                }
            {
                if (Input.GetKey(KeyCode.LeftControl))
                {
                    megaCharge++;
                    Debug.Log(megaCharge);
                    if (megaCharge == 100)
                    {
                        interactUI.SetActive(true);
                    }
                }
            }
        }
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("RainWizard"))
            topOfTower = true;
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("RainWizard"))
            topOfTower = true;

    }


    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("RainWizard"))
            topOfTower = false;
    }
}

